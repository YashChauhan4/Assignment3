#Image Name try3.jpg
import cv2
import pytesseract

# Path to Tesseract executable (change it according to your installation)
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

# Load the car image
car_image_path = ('C:\\Users\\abc\\Desktop\\try3.jpg')
car_image = cv2.imread(car_image_path)

# Convert the image to grayscale
gray_image = cv2.cvtColor(car_image, cv2.COLOR_BGR2GRAY)

# Apply image processing techniques (e.g., blur, thresholding) to enhance the license plate region
processed_image = cv2.medianBlur(gray_image, 5)
_, threshold_image = cv2.threshold(processed_image, 0, 500, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

# Perform OCR on the processed image
number_plate = pytesseract.image_to_string(threshold_image)

# Print the extracted number plate
print("Number Plate:", number_plate)

#Image Name try2.jpg
import cv2
import pytesseract

# Path to Tesseract executable (change it according to your installation)
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

# Load the car image
car_image_path = ('C:\\Users\\abc\\Desktop\\try2.jpg')
car_image = cv2.imread(car_image_path)

# Convert the image to grayscale
gray_image = cv2.cvtColor(car_image, cv2.COLOR_BGR2GRAY)

# Apply image processing techniques (e.g., blur, thresholding) to enhance the license plate region
processed_image = cv2.medianBlur(gray_image, 3)
_, threshold_image = cv2.threshold(processed_image, 0, 100, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

# Perform OCR on the processed image
number_plate = pytesseract.image_to_string(threshold_image)

# Print the extracted number plate
print("Number Plate:", number_plate)

#Image Name try5.jpg
import cv2
import pytesseract

# Path to Tesseract executable (change it according to your installation)
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

# Load the car image
car_image_path = ('C:\\Users\\abc\\Desktop\\try5.jpg')
car_image = cv2.imread(car_image_path)

# Convert the image to grayscale
gray_image = cv2.cvtColor(car_image, cv2.COLOR_BGR2GRAY)

# Apply image processing techniques (e.g., blur, thresholding) to enhance the license plate region
processed_image = cv2.medianBlur(gray_image, 3)
_, threshold_image = cv2.threshold(processed_image, 0, 200, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

# Perform OCR on the processed image
number_plate = pytesseract.image_to_string(threshold_image)

# Print the extracted number plate
print("Number Plate:", number_plate)
